-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 20, 2023 at 08:07 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elegant car`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblads`
--

DROP TABLE IF EXISTS `tblads`;
CREATE TABLE IF NOT EXISTS `tblads` (
  `Brand` varchar(20) NOT NULL,
  `Model` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` int NOT NULL,
  `imagepath` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `publish` int NOT NULL,
  `ADregistration` int NOT NULL AUTO_INCREMENT,
  `Category` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`ADregistration`)
) ENGINE=MyISAM AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tblads`
--

INSERT INTO `tblads` (`Brand`, `Model`, `price`, `imagepath`, `publish`, `ADregistration`, `Category`, `email`) VALUES
('Bugatti', 'Veyron', 2147483647, 'upload/veyron.png', 1, 15, 'Car', 'Admin'),
('Bugatti', 'Vision GT', 2147483647, 'upload/chiron visionGT.png', 1, 14, 'Car', 'Admin'),
('Bugatti', 'Bolid', 2147483647, 'upload/bxx-01-main.png', 1, 13, 'Car', 'Admin'),
('Bugatti', 'Divo', 2147483647, 'upload/bolide.png', 1, 16, 'Car', 'Admin'),
('Bugatti', 'Chiron', 2147483647, 'upload/Bugatti-PNG-Image.png', 1, 17, 'Car', 'Admin'),
('Toyota', 'Supra', 2147483647, 'upload/b22_db2c0_fl1_0d05_b.png', 1, 18, 'Car', 'Admin'),
('Audi', 'A8', 23000000, 'upload/Car-PNG-Photos-420x225.png', 1, 19, 'Car', 'Admin'),
('Lamborghini', 'Countach', 2147483647, 'upload/countach.jpg', 1, 20, 'Car', 'Admin'),
('Toyota', 'Yaris', 8000000, 'upload/toyota_PNG1946.png', 1, 21, 'Car', 'Admin'),
('Toyota', 'Corolla', 9000000, 'upload/Corolla.png', 1, 22, 'Car', 'Admin'),
('Lamborghini', 'MURCIELAGO', 2147483647, 'upload/murcielago.jpg', 1, 27, 'Car', 'Admin'),
('Lamborghini', 'GALLADRO', 2147483647, 'upload/Galladro.png', 1, 28, 'Car', 'Admin'),
('Lamborghini', 'HURACAN', 500000000, 'upload/Hurracane.png', 1, 29, 'Car', 'Admin'),
('Lamborghini', 'ADVENTADOR', 2147483647, 'upload/Adventador.png', 1, 30, 'Car', 'Admin'),
('Lamborghini', 'CENTANARIO', 2147483647, 'upload/Centanario.png', 1, 31, 'Car', 'Admin'),
('Benz', 'MAYBACH E-CLASS', 2147483647, 'upload/R (11).png', 1, 32, 'Car', 'Admin'),
('Toyota', 'Prius', 14000000, 'upload/Prius.png', 1, 33, 'Car', 'Admin'),
('Toyota', 'Camry', 13000000, 'upload/Camry.png', 1, 34, 'Car', 'Admin'),
('Honda', 'Fit', 8000000, 'upload/Fit.jpg', 1, 35, 'Car', 'Admin'),
('Honda', 'Accord', 18000000, 'upload/R (3).png', 1, 36, 'Car', 'Admin'),
('Mitsubishi', 'Attrage', 8000000, 'upload/Attrage.png', 1, 37, 'Car', 'Admin'),
('Rolls Royce', 'Cullinan', 999999999, 'upload/Cullinan.png', 1, 38, 'SUV', 'Admin'),
('Benz', 'MAYBACH GLS', 2147483647, 'upload/MaybackGLS.png', 1, 39, 'SUV', 'Admin'),
('Lamborghini', 'Urus', 2147483647, 'upload/Urus.png', 1, 40, 'SUV', 'Admin'),
('Benz', 'G63', 2147483647, 'upload/G63.png', 1, 41, 'SUV', 'Admin'),
('Audi', 'Q7', 2147483647, 'upload/Q7.png', 1, 42, 'SUV', 'Admin'),
('Cadillac', 'Escalade', 2147483647, 'upload/Escallade.jpg', 1, 43, 'SUV', 'Admin'),
('Toyota', '4Runner', 2147483647, 'upload/2016-Toyota-4Runner.png', 1, 44, 'SUV', 'Admin'),
('Toyota', 'Fortuner', 2147483647, 'upload/Fortuner.png', 1, 45, 'SUV', 'Admin'),
('Toyota', 'Landcrusier', 2147483647, 'upload/Landcrusier.png', 1, 46, 'SUV', 'Admin'),
('BMW', '520d', 30000000, 'upload/BMW.jpg', 1, 74, 'Car', 'Admin'),
('Toyota', 'RAV4', 30000000, 'upload/Rav4.png', 1, 48, 'SUV', 'Admin'),
('Honda', 'CRV', 30000000, 'upload/CRV.webp', 1, 49, 'SUV', 'Admin'),
('Honda', 'Vezel', 30000000, 'upload/Vessel.png', 1, 50, 'Car', 'Admin'),
('Mitsubishi', 'Montero', 30000000, 'upload/mitsubishi_PNG124.png', 1, 51, 'Car', 'Admin'),
('Mitsubishi', 'Montero Sport', 2147483647, 'upload/Monterosport.png', 1, 52, 'Car', 'Admin'),
('Mitsubishi', 'L200', 30000000, 'upload/L200.png', 1, 53, 'Car', 'Admin'),
('Toyota', 'Coaster', 30000000, 'upload/Toyota Coasternew.png', 1, 54, 'Bus', 'Admin'),
('Toyota', 'Coaster', 30000000, 'upload/Coaster.png', 1, 55, 'Bus', 'Admin'),
('Scania', 'bus', 30000000, 'upload/Scania.png', 1, 56, 'Bus', 'Admin'),
('Leyland', 'school bus', 30000000, 'upload/Leyland Bus.png', 1, 57, 'Bus', 'Admin'),
('Nissan', 'Civilian', 30000000, 'upload/Civilian.png', 1, 58, 'Bus', 'Admin'),
('Leyland', 'bus', 30000000, 'upload/Ashok-Leyland-67.png', 1, 59, 'Bus', 'Admin'),
('Mahidra', 'Bollero', 8000000, 'upload/Bollero.png', 1, 60, 'Truck', 'Admin'),
('Renault', 'Truck', 8000000, 'upload/Renault Truck.png', 1, 61, 'Truck', 'Admin'),
('TATA', 'Tipper', 2147483647, 'upload/TATA Tipper.png', 1, 62, 'Truck', 'Admin'),
('Leyland', 'Tipper', 8000000, 'upload/Tipper.png', 1, 63, 'Truck', 'Admin'),
('Leyland', 'Lorry', 2147483647, 'upload/Leyland Lorry.png', 1, 64, 'Truck', 'Admin'),
('Mahidra', 'Lorry', 2147483647, 'upload/Mahidra Lorry.png', 1, 65, 'Truck', 'Admin'),
('Mitsubishi', 'Lorry', 2147483647, 'upload/Mitsubhi Lorry.png', 1, 66, 'Truck', 'Admin'),
('TATA', 'Lorry', 2147483647, 'upload/TATA Lorry.png', 1, 67, 'Truck', 'Admin'),
('Benz', 'Vito', 2147483647, 'upload/Vito.png', 1, 68, 'Van', 'Admin'),
('Toyota', 'HIACE LIMITED EDITIO', 2147483647, 'upload/HIACE LIMITED EDITION.png', 1, 69, 'Van', 'Admin'),
('Toyota', 'HIACE KDH', 2147483647, 'upload/Hiace KDH.png', 1, 70, 'Van', 'Admin'),
('Toyota', 'HIACE', 2147483647, 'upload/HIACE.png', 1, 71, 'Car', 'Admin'),
('Nissan', 'NV300', 2147483647, 'upload/NV300.png', 1, 72, 'Van', 'Admin'),
('Nissan', 'Caravan', 30000000, 'upload/Caravan.png', 1, 73, 'Van', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `tblinquiry`
--

DROP TABLE IF EXISTS `tblinquiry`;
CREATE TABLE IF NOT EXISTS `tblinquiry` (
  `Email` varchar(30) NOT NULL,
  `Inquiry` varchar(100) NOT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `Email` varchar(30) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Contact_number` int NOT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`Email`, `Name`, `Password`, `Contact_number`) VALUES
('thamathanujan@gmail.com', 'Thanujan', '1234567', 987654321),
('Admin', 'admin', 'admin', 112436167),
('tharmavathsala@gmail.com', 'Tharsha', 'Jayaram@15', 776900159);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
